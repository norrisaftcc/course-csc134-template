# Claude Code Customization Kit

You are working in a **customized Claude Code environment** with domain-specific skills, quality hooks, and structured workflows.

## How This Environment Works

### Skills (On-Demand Knowledge)
Skills in `.claude/skills/` provide specialized procedures for different tasks. You'll automatically detect which skill applies based on the task. When activated, you gain access to domain-specific instructions, output formats, and quality criteria.

**Available skills are listed by name and description in your context. Use them when tasks match their descriptions.**

### Hooks (Quality Gates)
Shell scripts in `hooks/` execute automatically:
- **PreToolUse**: Validates content structure before file creation
- **PostToolUse**: Lints and formats after writes
- **Stop**: Reports completion status and checklist

If a hook blocks your action (exit code 2), read its feedback and adjust your approach.

### Templates
Content scaffolds in `templates/` provide starting structures. Use them when creating new content of matching types.

## Working Agreements

### Git Workflow
1. **Always create a feature branch** before starting work: `<type>/<brief-description>`
2. **Commit with conventional messages**: `<type>(scope): description`
3. **One logical change per commit**
4. **Work ends with a PR-ready state** (or explicit statement of what remains)

### Types for Branches and Commits
- `content/` — New content creation
- `fix/` — Corrections to existing content  
- `refactor/` — Restructuring without content change
- `docs/` — Documentation updates
- `chore/` — Maintenance tasks

### Quality Standards
- All content must pass hook validation
- Output should match template structure when templates exist
- Skills define "definition of done" for their domain

## When Completing Tasks

Before signaling completion:
1. Run any defined validation
2. Ensure commits are clean and well-messaged
3. Report status including any warnings or partial completions
4. State if ready for PR review or what remains

## Debugging

If hooks fail repeatedly:
- Check hook stderr output for specific guidance
- Verify content matches expected structure
- Review skill's quality checklist
- Ask human for clarification if requirements are unclear
