# Claude Code Customization Kit

A reusable framework for building domain-specific Claude Code environments with skills, hooks, and quality gates.

**Includes working example**: CSC-113 AI Fundamentals course content development system.

## Quick Start

```bash
# Clone this repo
git clone <repo-url> my-project
cd my-project

# Make hooks executable
chmod +x hooks/*.sh

# Start Claude Code
claude
```

## What's Included

| Component | Purpose |
|-----------|---------|
| `CLAUDE.md` | Root context (always loaded) |
| `.claude/CLAUDE.md` | Domain-specific context |
| `.claude/skills/` | On-demand knowledge injection |
| `hooks/` | Quality gates and automation |
| `templates/` | Content scaffolds |

## Adapting to Your Domain

1. **Edit `CLAUDE.md`**: Change project identity and working agreements
2. **Edit `.claude/CLAUDE.md`**: Add your domain context
3. **Copy `.claude/skills/_template/`**: Create skills for your content types
4. **Modify `hooks/`**: Adjust validation rules
5. **Update `templates/`**: Create scaffolds for your deliverables

## Workflow

```
Human: "Sprint goal: [deliverable]"
    ↓
Claude: Creates branch → activates skill → generates content
    ↓
Hooks: Validate structure, lint, report completion status
    ↓
Human: Review PR → approve or request changes
    ↓
Merge when satisfied
```

## Documentation

- **[Architecture Guide](docs/ARCHITECTURE.md)**: Deep dive into how it all works
- **[Skills Reference](.claude/skills/_template/SKILL.md)**: Template for creating skills
- **[Hook Examples](hooks/)**: Working validation scripts

## Example Skills (CSC-113)

| Skill | Purpose |
|-------|---------|
| `course-content-writer` | Domain voice and philosophy |
| `reading-generator` | Chapter reading creation |
| `lab-creator` | Hands-on lab development |
| `rubric-converter` | Assessment framework → usable rubrics |

## Requirements

- Claude Code CLI installed
- Bash shell (for hooks)
- Git (for PR workflow)

## License

MIT - Use, adapt, share freely.
