#!/bin/bash
# hooks/validate-content-structure.sh
# PreToolUse hook for Write operations on markdown/text files
# Validates content structure before allowing file creation
#
# Exit codes:
#   0 = Success, allow write
#   2 = Block write, return feedback to Claude
#   1 = Error but don't block

# Get input from environment
FILE_PATH="${CLAUDE_FILE_PATH:-}"
CONTENT="${CLAUDE_CONTENT:-}"

# If no file path, allow (probably not a file write)
if [ -z "$FILE_PATH" ]; then
    exit 0
fi

# Extract filename and extension
FILENAME=$(basename "$FILE_PATH")
EXTENSION="${FILENAME##*.}"

# Only validate markdown files in content directories
if [[ "$EXTENSION" != "md" ]]; then
    exit 0
fi

# Track validation failures
ERRORS=()
WARNINGS=()

# ============================================
# VALIDATION RULES
# ============================================

# Rule 1: Check for frontmatter in content files
if [[ "$FILE_PATH" == *"content/"* ]] || [[ "$FILE_PATH" == *"readings/"* ]] || [[ "$FILE_PATH" == *"labs/"* ]]; then
    if [[ ! "$CONTENT" =~ ^--- ]]; then
        ERRORS+=("Missing YAML frontmatter (must start with ---)")
    fi
fi

# Rule 2: Check for required frontmatter fields in readings
if [[ "$FILE_PATH" == *"readings/"* ]]; then
    if [[ ! "$CONTENT" =~ title: ]]; then
        ERRORS+=("Reading missing 'title:' in frontmatter")
    fi
    if [[ ! "$CONTENT" =~ estimated_time: ]]; then
        WARNINGS+=("Reading missing 'estimated_time:' in frontmatter")
    fi
    if [[ ! "$CONTENT" =~ "## Learning Objectives" ]]; then
        ERRORS+=("Reading missing '## Learning Objectives' section")
    fi
fi

# Rule 3: Check for required frontmatter fields in labs
if [[ "$FILE_PATH" == *"labs/"* ]]; then
    if [[ ! "$CONTENT" =~ title: ]]; then
        ERRORS+=("Lab missing 'title:' in frontmatter")
    fi
    if [[ ! "$CONTENT" =~ deliverables: ]]; then
        WARNINGS+=("Lab missing 'deliverables:' in frontmatter")
    fi
    if [[ ! "$CONTENT" =~ "## Submission" ]]; then
        ERRORS+=("Lab missing '## Submission' section")
    fi
fi

# Rule 4: Check for required sections in rubrics
if [[ "$FILE_PATH" == *"rubric"* ]] || [[ "$FILENAME" == *"rubric"* ]]; then
    if [[ ! "$CONTENT" =~ "| Level |" ]]; then
        ERRORS+=("Rubric missing level table (expected '| Level |' header)")
    fi
    if [[ ! "$CONTENT" =~ "Advanced" ]] || [[ ! "$CONTENT" =~ "Proficient" ]]; then
        ERRORS+=("Rubric missing standard competency levels (Advanced, Proficient, Developing, Novice)")
    fi
fi

# Rule 5: Word count check for readings (warning only)
if [[ "$FILE_PATH" == *"readings/"* ]]; then
    WORD_COUNT=$(echo "$CONTENT" | wc -w)
    if [ "$WORD_COUNT" -lt 500 ]; then
        WARNINGS+=("Reading seems short ($WORD_COUNT words, target is 1500-2500)")
    fi
fi

# Rule 6: Check for banned phrases
BANNED_PHRASES=("obviously" "simply put" "it's easy" "everyone knows" "stupid")
for phrase in "${BANNED_PHRASES[@]}"; do
    if echo "$CONTENT" | grep -qi "$phrase"; then
        WARNINGS+=("Contains discouraged phrase: '$phrase' - review voice guidelines")
    fi
done

# Rule 7: Check for empty file
if [ -z "$CONTENT" ] || [ ${#CONTENT} -lt 50 ]; then
    ERRORS+=("Content is empty or too short (less than 50 characters)")
fi

# ============================================
# OUTPUT RESULTS
# ============================================

# If there are errors, block the write
if [ ${#ERRORS[@]} -gt 0 ]; then
    echo "❌ Content validation failed for: $FILE_PATH" >&2
    echo "" >&2
    echo "ERRORS (must fix):" >&2
    for error in "${ERRORS[@]}"; do
        echo "  • $error" >&2
    done
    
    if [ ${#WARNINGS[@]} -gt 0 ]; then
        echo "" >&2
        echo "WARNINGS (should review):" >&2
        for warning in "${WARNINGS[@]}"; do
            echo "  • $warning" >&2
        done
    fi
    
    echo "" >&2
    echo "Please fix the errors above and try again." >&2
    exit 2
fi

# If there are only warnings, allow but report
if [ ${#WARNINGS[@]} -gt 0 ]; then
    echo "⚠️ Content validation passed with warnings for: $FILE_PATH"
    echo ""
    echo "WARNINGS (consider addressing):"
    for warning in "${WARNINGS[@]}"; do
        echo "  • $warning"
    done
    exit 0
fi

# All good
echo "✓ Content validation passed for: $FILE_PATH"
exit 0
