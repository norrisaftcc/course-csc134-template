#!/bin/bash
# hooks/lint-and-format.sh
# PostToolUse hook for Write operations on markdown files
# Performs post-write validation and optional formatting
#
# This hook runs AFTER the file is written, so it can:
# - Report issues for next iteration
# - Log metrics
# - Run external tools (if available)
#
# Exit codes:
#   0 = Success (or non-blocking issues found)
#   Non-zero = Error logged but doesn't block (file already written)

# Get input from environment
FILE_PATH="${CLAUDE_FILE_PATH:-}"

# If no file path, exit quietly
if [ -z "$FILE_PATH" ]; then
    exit 0
fi

# Only process markdown files
if [[ ! "$FILE_PATH" =~ \.md$ ]]; then
    exit 0
fi

# Check if file exists
if [ ! -f "$FILE_PATH" ]; then
    echo "Warning: File not found after write: $FILE_PATH"
    exit 0
fi

# ============================================
# POST-WRITE CHECKS
# ============================================

REPORT=()

# Get file stats
WORD_COUNT=$(wc -w < "$FILE_PATH")
LINE_COUNT=$(wc -l < "$FILE_PATH")
CHAR_COUNT=$(wc -c < "$FILE_PATH")

REPORT+=("📄 File: $FILE_PATH")
REPORT+=("   Words: $WORD_COUNT | Lines: $LINE_COUNT | Chars: $CHAR_COUNT")

# Check for common markdown issues
CONTENT=$(cat "$FILE_PATH")

# Check for trailing whitespace
TRAILING_WS=$(grep -c '[[:space:]]$' "$FILE_PATH" 2>/dev/null || echo "0")
if [ "$TRAILING_WS" -gt 0 ]; then
    REPORT+=("   ⚠️ Found $TRAILING_WS lines with trailing whitespace")
fi

# Check for multiple consecutive blank lines
MULTI_BLANK=$(grep -c '^$' "$FILE_PATH" 2>/dev/null || echo "0")
if [ "$MULTI_BLANK" -gt 10 ]; then
    REPORT+=("   ⚠️ Many blank lines ($MULTI_BLANK) - consider reducing")
fi

# Check for very long lines (>120 chars)
LONG_LINES=$(awk 'length > 120 {count++} END {print count+0}' "$FILE_PATH")
if [ "$LONG_LINES" -gt 0 ]; then
    REPORT+=("   ⚠️ Found $LONG_LINES lines over 120 characters")
fi

# Check for TODO/FIXME markers
TODO_COUNT=$(grep -ci 'TODO\|FIXME\|XXX' "$FILE_PATH" || echo "0")
if [ "$TODO_COUNT" -gt 0 ]; then
    REPORT+=("   📝 Found $TODO_COUNT TODO/FIXME markers")
fi

# Check heading structure
H1_COUNT=$(grep -c '^# ' "$FILE_PATH" || echo "0")
if [ "$H1_COUNT" -gt 1 ]; then
    REPORT+=("   ⚠️ Multiple H1 headers ($H1_COUNT) - should have only one")
elif [ "$H1_COUNT" -eq 0 ]; then
    REPORT+=("   ⚠️ No H1 header found")
fi

# Check for broken links (basic check)
BROKEN_LINK_PATTERN='\[.*\]\(\s*\)'
if grep -qE "$BROKEN_LINK_PATTERN" "$FILE_PATH"; then
    REPORT+=("   ⚠️ Found empty link references []() ")
fi

# Check for unclosed code blocks
BACKTICK_BLOCKS=$(grep -c '```' "$FILE_PATH" || echo "0")
if [ $((BACKTICK_BLOCKS % 2)) -ne 0 ]; then
    REPORT+=("   ⚠️ Unclosed code block (odd number of \`\`\` markers)")
fi

# ============================================
# OPTIONAL: Run external tools if available
# ============================================

# Try markdownlint if installed
if command -v markdownlint &> /dev/null; then
    LINT_OUTPUT=$(markdownlint "$FILE_PATH" 2>&1)
    if [ -n "$LINT_OUTPUT" ]; then
        LINT_COUNT=$(echo "$LINT_OUTPUT" | wc -l)
        REPORT+=("   🔍 markdownlint: $LINT_COUNT issues found")
    else
        REPORT+=("   ✓ markdownlint: passed")
    fi
fi

# Try prettier if installed (just check, don't modify)
if command -v prettier &> /dev/null; then
    if ! prettier --check "$FILE_PATH" &> /dev/null; then
        REPORT+=("   📐 prettier: formatting differs from standard")
    fi
fi

# ============================================
# OUTPUT REPORT
# ============================================

echo ""
echo "═══════════════════════════════════════════"
echo "POST-WRITE REPORT"
echo "═══════════════════════════════════════════"
for line in "${REPORT[@]}"; do
    echo "$line"
done
echo "═══════════════════════════════════════════"
echo ""

# ============================================
# LOGGING (optional)
# ============================================

# Log to file for metrics tracking
LOG_DIR=".claude/logs"
if [ -d "$LOG_DIR" ] || mkdir -p "$LOG_DIR" 2>/dev/null; then
    LOG_FILE="$LOG_DIR/write-log.csv"
    
    # Create header if file doesn't exist
    if [ ! -f "$LOG_FILE" ]; then
        echo "timestamp,file,words,lines,chars,warnings" > "$LOG_FILE"
    fi
    
    # Count warnings (lines starting with ⚠️)
    WARNING_COUNT=$(printf '%s\n' "${REPORT[@]}" | grep -c '⚠️' || echo "0")
    
    # Append log entry
    echo "$(date -Iseconds),$FILE_PATH,$WORD_COUNT,$LINE_COUNT,$CHAR_COUNT,$WARNING_COUNT" >> "$LOG_FILE"
fi

exit 0
