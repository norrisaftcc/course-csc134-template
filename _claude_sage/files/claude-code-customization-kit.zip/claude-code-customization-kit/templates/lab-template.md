---
title: "Lab X: [Lab Title]"
module: M0X
lab_number: X
estimated_time: "XX minutes"
prerequisites:
  readings:
    - "[Relevant reading]"
  labs:
    - "[Previous lab, if any]"
  tools:
    - "[Required tool/account]"
deliverables:
  - "[Specific file or artifact]"
  - "[Another deliverable]"
---

# Lab X: [Lab Title]

## Overview

[1-2 paragraphs explaining:
- What you'll build/do in this lab
- Why this matters (connection to course/career)
- What success looks like]

## Learning Outcomes

In this lab, you'll practice:

- [Doing X] (action-oriented, not "understanding")
- [Creating Y]
- [Implementing Z]

---

## Before You Begin

### Prerequisites Check

Make sure you have:

- [ ] Completed [Reading X]
- [ ] Access to [required tool/account]
- [ ] [Other prerequisite]

### Time Estimate

This lab takes approximately **XX minutes**. If you're new to [topic], budget extra time.

### Create Your Issue

Before starting, create a GitHub Issue:

1. Go to your repository → Issues → New Issue
2. Title: "Lab X: [Brief description]"
3. Assign yourself
4. Add label: `lab`

---

## Part 1: [First Major Section]

### Step 1.1: [Specific Action]

[Detailed instructions. Someone unfamiliar should be able to follow without guessing.]

1. [First specific action]
2. [Second specific action]
3. [Third specific action]

You should see: [Description of expected result]

> **💡 Tip**: [Helpful context or shortcut]

### Step 1.2: [Next Action]

[Continue with same level of detail]

```
[Code or command example if relevant]
```

### 📝 Commit Point

You've completed a logical chunk. Commit now:

```bash
git add [files]
git commit -m "[type]: [description of what you did]"
```

---

## Part 2: [Second Major Section]

### Step 2.1: [Action]

[Instructions continue...]

### Step 2.2: [Action]

[Instructions continue...]

> **⚠️ Common Pitfall**: [Warning about mistake to avoid]

### 📝 Commit Point

```bash
git commit -m "[type]: [description]"
```

---

## Checkpoint: Verify Your Progress

At this point, you should have:

- [ ] [First milestone achieved]
- [ ] [Second milestone achieved]
- [ ] [Third milestone achieved]

**If anything is missing**, review the steps above before continuing.

---

## Part 3: [Final Section / Polish]

### Step 3.1: [Action]

[Final implementation steps...]

### Step 3.2: [Action]

[Clean up, testing, etc.]

---

## Stretch Goals (Optional)

Finished early? Try these challenges:

1. **[Stretch Goal 1]**: [Brief description]
2. **[Stretch Goal 2]**: [Brief description]
3. **[Stretch Goal 3]**: [Brief description]

---

## Troubleshooting

### "[Common error message or problem]"

**Cause**: [Why this happens]

**Solution**: [How to fix it]

### "[Another common issue]"

**Cause**: [Explanation]

**Solution**: [Steps to resolve]

### Still stuck?

- Check the class Discord/discussion forum
- Review the relevant reading
- Create a detailed Issue describing your problem

---

## Submission

Your lab is complete when:

### GitHub Requirements

- [ ] **Branch**: Work is on feature branch (not main)
- [ ] **Commits**: At least [X] commits with meaningful messages
- [ ] **Files**: [List specific files that should exist]

### Pull Request

1. Push your branch: `git push origin [branch-name]`
2. Go to your repository → Pull Requests → New Pull Request
3. Set base: `main`, compare: `[your-branch]`
4. Title: `[Lab X]: [Brief description]`
5. Description: Use the PR template, link to Issue with `Fixes #[number]`

### Quality Check

Before submitting, verify:

- [ ] [Specific quality criterion]
- [ ] [Another criterion]
- [ ] [Final criterion]

**Do not merge** until peer review is complete (if required).

---

## Reflection

After completing this lab, consider:

1. What was the most challenging part? How did you work through it?
2. How does this connect to what you learned in the reading?
3. What would you do differently next time?

Add a brief reflection comment to your PR before requesting review.

---

*Estimated completion time: XX minutes*
