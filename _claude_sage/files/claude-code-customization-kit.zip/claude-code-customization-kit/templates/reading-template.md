---
title: "[Reading Title]"
module: M0X
reading_number: X
estimated_time: "XX minutes"
prerequisites: 
  - "[Previous reading or 'None']"
---

# [Reading Title]

## Learning Objectives

By the end of this reading, you'll be able to:

- [Action verb] + [specific skill/knowledge]
- [Action verb] + [specific skill/knowledge]
- [Action verb] + [specific skill/knowledge]
- [Action verb] + [specific skill/knowledge] (optional: 4-5 objectives)

## Why This Matters

[1-2 paragraphs connecting this topic to:
- Real-world relevance / careers
- The course project (SAGE)
- Daily life impact
- Skills employers value]

---

## The Core Concept

### [First Major Section - Start with Hook]

[Open with a concrete, relatable example or scenario. Draw the reader in before explaining theory.]

[Define the core concept clearly. Use analogies if helpful.]

> **💡 Key Insight**: [One-sentence summary of the most important point]

### [Second Major Section]

[Build on the first section. Add complexity gradually.]

[Include code examples or practical illustrations where relevant:]

```
[Example code or formatted content]
```

### [Third Major Section (as needed)]

[Continue building the concept. Connect to prior knowledge.]

> **🔗 Connection**: [Link to something they learned earlier or will learn later]

---

## Putting It Together

[Synthesize the pieces. Help readers see the big picture:]

- How do these concepts connect?
- What's the main takeaway?
- How does this change how you think about X?

---

## Common Questions

**"[Question students actually ask]"**

[Direct, helpful answer]

**"[Another common question]"**

[Answer with specific guidance]

**"[Question about when/how to apply this]"**

[Practical answer with example]

---

## Reflection Questions

Take a moment to consider:

1. [Open-ended question prompting genuine thinking, not recall]
2. [Question connecting to personal experience or interests]
3. [Question about application to their goals]

---

## Next Steps

**Required**:
- [ ] Complete [Lab X] to practice these concepts
- [ ] [Any other required action]

**Optional Deep Dive**:
- [Link to additional resource]
- [Suggestion for further exploration]

---

*Estimated reading time: XX minutes*
