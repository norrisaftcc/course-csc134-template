---
rubric_type: "[lab|project|portfolio|presentation]"
assignment: "[Specific assignment name]"
total_points: 100
version: "1.0"
last_updated: "[Date]"
---

# Rubric: [Assignment Name]

## Overview

This rubric evaluates [brief description of what's being assessed].

**Total Points**: 100
**Categories**: 4

---

## Category 1: AI Partnership Quality (25 points)

Evaluates how effectively the student collaborates with AI tools.

| Level | Points | Criteria |
|-------|--------|----------|
| **Advanced (4)** | 25 | All of Proficient, PLUS: Documents sophisticated prompt iteration with reflection on why changes improved results; demonstrates meta-cognitive awareness of AI collaboration patterns; shows evidence of knowing when NOT to use AI |
| **Proficient (3)** | 19 | Documents prompts used and shows 2+ iterations; critically evaluates AI outputs before accepting; selects appropriate AI tools for different subtasks; integrates AI assistance with own judgment |
| **Developing (2)** | 13 | Some prompt documentation but limited iteration visible; accepts most AI output without clear evaluation; uses AI but approach is inconsistent; partial integration with own work |
| **Novice (1)** | 6 | Minimal or no documentation of AI use; appears to accept AI output uncritically; no visible iteration or refinement; AI use seems disconnected from learning objectives |

**Observable Evidence**:
- Prompt history in documentation or commit messages
- Comments evaluating AI suggestions
- Evidence of trying multiple approaches
- Notes explaining tool selection choices

---

## Category 2: Problem-Solving Process (25 points)

Evaluates systematic approach to solving problems and documenting the journey.

| Level | Points | Criteria |
|-------|--------|----------|
| **Advanced (4)** | 25 | All of Proficient, PLUS: Approach shows creative problem decomposition; testing is comprehensive with edge cases; reflection demonstrates deep learning from both successes and failures |
| **Proficient (3)** | 19 | Clear problem definition in Issue/documentation; systematic approach visible in commit history; evidence of testing and validation; meaningful reflection on process in PR/retrospective |
| **Developing (2)** | 13 | Problem definition present but vague; some structure in approach but gaps visible; limited testing evidence; reflection is superficial or missing specifics |
| **Novice (1)** | 6 | Jumps to solution without clear problem definition; chaotic or missing commit history; no visible testing; little to no reflection on process |

**Observable Evidence**:
- Issue descriptions with clear problem statements
- Commit messages showing logical progression
- Test results or validation documentation
- Retrospective or PR comments reflecting on process

---

## Category 3: Professional Communication (25 points)

Evaluates documentation, collaboration, and presentation of work.

| Level | Points | Criteria |
|-------|--------|----------|
| **Advanced (4)** | 25 | All of Proficient, PLUS: Documentation could serve as reference for others; peer reviews are notably helpful and specific; work is portfolio-ready with professional polish |
| **Proficient (3)** | 19 | README is clear and complete (setup, usage, examples); code/content has appropriate comments; peer reviews are constructive and actionable; PR descriptions explain what and why |
| **Developing (2)** | 13 | README exists but missing key sections; inconsistent documentation quality; peer reviews are present but generic ("looks good"); PR descriptions are minimal |
| **Novice (1)** | 6 | Documentation is absent or template-only; no meaningful peer review participation; work is difficult for others to understand or evaluate |

**Observable Evidence**:
- README completeness and clarity
- Code comments and inline documentation
- Quality of peer review comments given
- PR and Issue description quality

---

## Category 4: Critical Thinking & Ethics (25 points)

Evaluates independent judgment, awareness of limitations, and ethical reasoning.

| Level | Points | Criteria |
|-------|--------|----------|
| **Advanced (4)** | 25 | All of Proficient, PLUS: Proactively considers implications beyond immediate task; demonstrates nuanced understanding of AI limitations; raises and addresses ethical considerations unprompted |
| **Proficient (3)** | 19 | Questions AI outputs with specific examples; identifies at least 2 limitations or potential biases; makes documented decisions to override AI suggestions; considers user impact |
| **Developing (2)** | 13 | Some questioning of AI visible but inconsistent; acknowledges limitations exist but vaguely; limited evidence of independent judgment; ethical considerations mentioned but not developed |
| **Novice (1)** | 6 | Accepts AI output without visible questioning; no acknowledgment of limitations or bias potential; no evidence of independent judgment; ethical dimensions not considered |

**Observable Evidence**:
- Comments questioning or correcting AI suggestions
- Documentation of identified limitations
- Decisions explained with reasoning
- Ethical considerations in reflection or documentation

---

## Scoring Guide

### Point Calculation

1. Score each category (1-4 scale)
2. Multiply by category weight:
   - Advanced (4): Full points
   - Proficient (3): 76% of points
   - Developing (2): 52% of points  
   - Novice (1): 24% of points
3. Sum all categories

### Quick Scoring Table

| Level | Cat 1 | Cat 2 | Cat 3 | Cat 4 | Total |
|-------|-------|-------|-------|-------|-------|
| All Advanced | 25 | 25 | 25 | 25 | 100 |
| All Proficient | 19 | 19 | 19 | 19 | 76 |
| All Developing | 13 | 13 | 13 | 13 | 52 |
| All Novice | 6 | 6 | 6 | 6 | 24 |

### Grade Boundaries (if applicable)

| Grade | Points | Meaning |
|-------|--------|---------|
| A | 90-100 | Exceeds expectations |
| B | 80-89 | Meets all expectations |
| C | 70-79 | Meets most expectations |
| D | 60-69 | Meets some expectations |
| F | <60 | Does not meet expectations |

---

## Calibration Notes

### Category 1: AI Partnership Quality

**Advanced Example**: Student's documentation includes: "First prompt: 'Write a function to sort data.' Result was too generic. Second prompt: 'Write a Python function to sort a list of dictionaries by the date field, handling missing dates by placing them last.' Third iteration added error handling after I noticed the function crashed on empty lists."

**Proficient Example**: PR includes "Prompts Used" section with 3 prompts shown, brief note saying "Had to modify the AI's suggestion to handle our specific data format."

**Developing Example**: Commit message says "used ChatGPT to help with sorting" but no prompts documented and no evidence of iteration.

### Category 3: Professional Communication

**Advanced Example**: README includes: project description, installation steps with troubleshooting, usage examples with screenshots, API documentation, contribution guidelines, and known limitations.

**Proficient Example**: README has description, basic setup, usage example, and notes about what the project does.

**Developing Example**: README is mostly the template with project description filled in but setup instructions are incomplete.

---

## Assessor Notes

- When scoring between levels, consider the preponderance of evidence
- Partial credit within levels is acceptable (e.g., 16/25 for "strong Developing")
- Document specific examples when scoring below Proficient
- Consider trajectory/improvement when making borderline decisions

---

*Rubric Version: 1.0 | Last Updated: [Date]*
