# CSC-113 AI Fundamentals: Course Development Context

## Project Identity

This is the **content development environment** for CSC-113 AI Fundamentals, a community college course teaching AI collaboration and professional workflows to students aged 18-65 with no prerequisites.

## The Philosophy: "Failure is Just Exercise"

This phrase captures everything:
- **Learning through iteration**, not perfection
- **GitHub workflow from Day 1** — Issues → Branches → PRs → Review → Merge
- **AI as collaborator**, not replacement for thinking
- **Professional habits with creative freedom**
- **Process is the scaffolding** that enables safe experimentation

When creating content, embody this philosophy. Never make students feel bad for mistakes. Always frame setbacks as learning opportunities.

## Audience

**Primary**: Community college students, 18-65, no CS prerequisites
- Some are career changers, some fresh from high school
- Many are intimidated by technology
- Most have jobs, families, limited time
- All deserve respect regardless of starting point

**Secondary**: Instructors using these materials
- May not be AI experts themselves
- Need practical, day-by-day guidance
- Value clear rationale for pedagogical choices

## Course Structure

| Module | Weeks | Focus |
|--------|-------|-------|
| M01 | 1-2 | AI Foundations & GitHub Workflow |
| M02 | 3-4 | Your First AI Assistant |
| M03 | 5-6 | Prompt Engineering Fundamentals |
| M04 | 7-8 | AI-Assisted Problem Solving |
| M05 | 9-10 | Specialization Tracks |
| M06 | 11-12 | Building AI Applications |
| M07 | 13-14 | Real-World Integration |
| M08 | 15-16 | Capstone & Portfolio Defense |

## Content Types

### Readings
- 1,500-2,500 words
- Conversational but substantive
- Include concrete examples
- End with reflection questions

### Tutorials
- Step-by-step with screenshots (described)
- Every action explicit
- Include "what if it doesn't work" troubleshooting
- Chunk into digestible sections

### Labs
- Hands-on, completable in 60-90 minutes
- Clear deliverable (committed to GitHub)
- Scaffolded difficulty within lab
- Peer component when possible

### Rubrics
- 4 competency levels: Novice, Developing, Proficient, Advanced
- Observable behaviors, not vague qualities
- Specific to each assessment type

## Voice Guidelines

### Do
- Use "we" and "you" to create partnership
- Acknowledge difficulty ("This can feel overwhelming—that's normal")
- Celebrate small wins explicitly
- Connect to real-world relevance
- Use analogies from everyday life

### Don't
- Talk down or over-explain obvious things
- Use jargon without definition
- Assume students have unlimited time
- Make anyone feel stupid for not knowing something
- Use exclusionary "obviously" or "simply"

## Technical Stack Reference

**Primary AI**: Gemini 2.5 Flash (1,000 requests/day free tier)
**Backup**: Claude, ChatGPT, local Ollama
**Development**: GitHub, GitHub Codespaces
**Project**: SAGE (Study Assistant & Guide Engine)

## File Organization

```
content/
├── module-01/
│   ├── readings/
│   │   ├── 01-what-is-ai.md
│   │   └── 02-github-workflow.md
│   ├── tutorials/
│   ├── labs/
│   └── assessments/
├── module-02/
│   └── ...
└── shared/
    ├── templates/
    └── rubrics/
```

## Critical Constraints

**Never**:
- Create content that requires paid AI services
- Assume students have powerful hardware
- Skip the GitHub workflow steps
- Use code examples without explanation
- Create walls of text without structure

**Always**:
- Include estimated time for activities
- Provide multiple entry points for different skill levels
- Test instructions yourself (or note "untested")
- Reference existing course philosophy documents
