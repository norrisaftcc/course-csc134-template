---
name: skill-template
description: "Template for creating new skills - copy this folder and customize"
allowed-tools: "Read,Write,Glob,Grep,Bash"
---

# Skill Template

Copy this skill folder to create new domain-specific skills.

## When to Use This Skill

Describe the conditions that should trigger this skill:
- What task types should activate it?
- What keywords or patterns indicate this skill applies?
- What distinguishes this from other skills?

## Core Instructions

### Step 1: Understand the Request
[How to analyze and clarify what's needed]

### Step 2: Plan the Approach
[How to structure the work]

### Step 3: Execute
[The actual procedures to follow]

### Step 4: Validate
[How to check work before declaring complete]

## Output Format

Describe the expected deliverable structure:

```
[filename-pattern]
├── [section 1]
├── [section 2]
└── [section 3]
```

## Quality Checklist

Before completing work with this skill:

- [ ] [Required element 1]
- [ ] [Required element 2]
- [ ] [Required element 3]
- [ ] [Quality standard 1]
- [ ] [Quality standard 2]

## Examples

### Good Example
[Show what excellent output looks like]

### Problematic Example
[Show what to avoid and why]

## Reference Files

If this skill needs extended documentation:
- Store additional files in this skill's folder
- Reference them by relative path: `./references/extended-docs.md`
- These load on-demand, not automatically

## Customization Notes

When adapting this template:
1. Change the `name` in frontmatter (lowercase, hyphenated)
2. Write a clear one-line `description` for LLM matching
3. Restrict `allowed-tools` to what's actually needed
4. Delete these customization notes
