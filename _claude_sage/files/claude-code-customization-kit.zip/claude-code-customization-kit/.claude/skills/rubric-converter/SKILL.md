---
name: rubric-converter
description: "Transform assessment criteria into structured, usable rubrics with observable behaviors"
allowed-tools: "Read,Write,Glob,Grep"
---

# Rubric Converter

Transform assessment frameworks and criteria into structured rubrics with observable behaviors at each competency level.

## When to Use This Skill

- Converting assessment philosophy into usable rubrics
- Creating grading criteria for specific assignments
- Standardizing evaluation across multiple assessors
- When asked to "create a rubric for X"

## Rubric Specifications

### CSC-113 Competency Levels

All rubrics use four levels:

| Level | Label | Meaning |
|-------|-------|---------|
| 4 | Advanced | Exceeds expectations, demonstrates mastery |
| 3 | Proficient | Meets all expectations, solid competency |
| 2 | Developing | Partially meets expectations, shows growth |
| 1 | Novice | Beginning stage, significant gaps |

**Note**: There is no "0" level. If work is submitted, it's at least Novice. Missing work is handled separately.

### Rubric Structure

```markdown
---
rubric_type: "[lab|project|portfolio|presentation]"
assignment: "[Specific assignment name]"
total_points: [Points]
categories: [Number of categories]
---

# Rubric: [Assignment Name]

## Overview
[Brief description of what this rubric evaluates]

## Category 1: [Name] (X points)

| Level | Points | Criteria |
|-------|--------|----------|
| Advanced (4) | X | [Observable behaviors] |
| Proficient (3) | X | [Observable behaviors] |
| Developing (2) | X | [Observable behaviors] |
| Novice (1) | X | [Observable behaviors] |

## Category 2: [Name] (X points)
[Continue pattern]

## Scoring Guide

### Point Calculation
[How to calculate final score]

### Grade Boundaries
[If applicable, how points map to grades]

## Calibration Notes
[Examples or guidance for consistent scoring]
```

## Writing Observable Behaviors

### The Core Principle

**Observable** = Can be verified by looking at the work
**Not Observable** = Requires mind-reading

| Not Observable ❌ | Observable ✅ |
|-------------------|---------------|
| "Understands Git" | "Commits have descriptive messages following conventional format" |
| "Shows effort" | "At least 5 commits over multiple days" |
| "Good documentation" | "README includes setup instructions, usage examples, and screenshots" |
| "Critical thinking" | "Evaluation document identifies 3+ specific limitations with evidence" |

### Behavior Formula

```
[Artifact] + [Action/Quality] + [Specificity]
```

Examples:
- "Pull request description explains the problem solved and approach taken"
- "Code includes comments explaining non-obvious logic (at least 1 per function)"
- "Presentation stays within 7-minute limit with time for Q&A"

### Level Differentiation

Levels should differ in:
- **Quantity**: How many examples, how much depth
- **Quality**: How well-executed, how sophisticated
- **Independence**: How much guidance needed
- **Consistency**: How reliable the performance

**Example progression for "Documentation"**:

| Level | Observable Behavior |
|-------|---------------------|
| Advanced | README includes setup, usage, examples, troubleshooting, AND contribution guidelines; documentation is complete enough for someone unfamiliar to use the project |
| Proficient | README includes setup instructions, usage examples, and at least one screenshot; key functions have docstrings |
| Developing | README exists with basic description; some functions documented; missing sections or incomplete |
| Novice | Minimal or template-only README; little to no code documentation |

## The Four CSC-113 Assessment Categories

All assignments should map to these four categories (adjust weights as needed):

### 1. AI Partnership Quality
What to observe:
- Prompt iteration patterns in documentation
- Evidence of evaluating AI suggestions
- Appropriate tool selection for tasks
- Learning from AI feedback

### 2. Problem-Solving Process
What to observe:
- Problem definition clarity
- Approach planning evidence
- Testing and validation documentation
- Reflection on what worked/didn't

### 3. Professional Communication
What to observe:
- Documentation clarity and completeness
- Peer review quality (given and received)
- Presentation effectiveness
- Audience-appropriate technical communication

### 4. Critical Thinking & Ethics
What to observe:
- Evidence of questioning AI outputs
- Consideration of limitations and bias
- Independent judgment demonstrations
- Ethical reasoning in decisions

## Assignment-Specific Adaptation

### For Labs
- Weight problem-solving process heavily
- Include "completion" criteria (did they finish?)
- Focus on process documentation in GitHub

### For Projects
- Balance all four categories
- Include deliverable quality criteria
- Consider scope and ambition

### For Portfolios
- Emphasize professional communication
- Include growth/progression criteria
- Consider presentation and organization

### For Presentations
- Weight communication heavily
- Include time management
- Consider audience engagement

## Calibration Examples

Include concrete examples at each level:

```markdown
## Calibration Notes

### Category: AI Partnership Quality

**Advanced Example**: Student's PR includes a "Prompts Used" section showing 
5+ iterations with notes like "Changed from asking for 'a function' to 
'a function that handles edge case X' after first version missed error handling."

**Proficient Example**: Student documents 2-3 prompts used, shows some iteration,
but limited reflection on why changes were made.

**Developing Example**: Student mentions using AI but provides only final prompt,
no iteration visible, accepts AI output without apparent evaluation.

**Novice Example**: No documentation of AI use despite assignment requiring it,
or documentation is generic ("used ChatGPT to help").
```

## Quality Checklist

Before completing a rubric:

- [ ] Uses the four-level scale (Advanced, Proficient, Developing, Novice)
- [ ] All criteria are observable behaviors (not traits or feelings)
- [ ] Each level is clearly differentiated from others
- [ ] Points are assigned and total correctly
- [ ] Maps to the four CSC-113 assessment categories
- [ ] Includes calibration examples for ambiguous criteria
- [ ] Language is consistent with course voice
- [ ] Could be used by a different instructor and produce similar scores

## Point Allocation Strategies

### Equal Weighting
When all categories matter equally:
```
4 categories × 25 points each = 100 points
```

### Primary Focus
When assignment emphasizes one area:
```
Primary category: 40 points
Secondary category: 30 points
Supporting categories: 15 points each
```

### Pass/Fail Checkboxes + Quality
When there are required elements:
```
Required elements (complete/incomplete): 40 points
Quality of work (rubric): 60 points
```

## Common Mistakes to Avoid

**Vague descriptors**:
- ❌ "Excellent work"
- ✅ "All required sections present with depth (300+ words each)"

**Personality judgments**:
- ❌ "Shows enthusiasm"
- ✅ "Optional stretch goals attempted"

**Instructor-dependent criteria**:
- ❌ "Meets my expectations"
- ✅ "Meets specifications in assignment document"

**Impossible to fail**:
- ❌ Novice level describes competent work
- ✅ Novice level describes genuine starting point

**Impossible to excel**:
- ❌ Advanced just adds "excellent" to Proficient
- ✅ Advanced describes genuinely exceptional work

## Template for Quick Rubric Generation

When creating rubrics quickly, start with this and customize:

```markdown
## [Category Name] (25 points)

| Level | Points | Criteria |
|-------|--------|----------|
| Advanced (4) | 25 | All of Proficient, PLUS: [exceptional addition] |
| Proficient (3) | 19 | [Core competency behaviors, 2-3 bullets] |
| Developing (2) | 13 | [Partial completion, 2-3 bullets describing gaps] |
| Novice (1) | 6 | [Minimal acceptable submission, what's present] |
```
