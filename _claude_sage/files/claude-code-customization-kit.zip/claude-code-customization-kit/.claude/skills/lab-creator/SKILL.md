---
name: lab-creator
description: "Create hands-on lab exercises with GitHub integration and clear deliverables"
allowed-tools: "Read,Write,Glob,Grep,Bash"
---

# Lab Creator

Create hands-on lab exercises that reinforce concepts through practice, integrated with GitHub workflow.

## When to Use This Skill

- Creating new lab assignments
- Designing hands-on exercises
- Building practice activities with deliverables
- When asked to "create a lab for X"

## Lab Specifications

### Scope & Timing
- **Duration**: 60-90 minutes of focused work
- **Deliverable**: Always something concrete committed to GitHub
- **Complexity**: Scaffolded (start simple, build up)
- **Independence**: Completable without instructor present

### Required Structure

```markdown
---
title: "Lab Title"
module: M0X
lab_number: X
estimated_time: "XX minutes"
prerequisites: 
  - reading: "relevant-reading"
  - lab: "previous-lab" (if applicable)
deliverables:
  - "Specific file or artifact"
  - "Another deliverable"
---

# Lab X: [Title]

## Overview
[1-2 paragraphs: what you'll do and why]

## Learning Outcomes
[What skills you'll practice - not just concepts]

## Before You Begin
[Prerequisites check, setup, materials needed]

## Part 1: [First Major Section]
### Step 1.1: [Specific Action]
### Step 1.2: [Next Action]
[Continue as needed]

## Part 2: [Second Major Section]
[Continue pattern]

## Checkpoint: Verify Your Progress
[How to confirm you're on track]

## Stretch Goals (Optional)
[For students who finish early or want more challenge]

## Troubleshooting
[Common issues and solutions]

## Submission
[Exactly how to submit/what to commit]

## Reflection
[Brief questions connecting practice to concepts]
```

## Section-by-Section Guidance

### Overview
Set expectations immediately:
- What they'll build/do
- Why it matters (connect to course/career)
- What success looks like

**Example**:
> In this lab, you'll create your first GitHub Issue, work on a branch, and submit a Pull Request. These three steps form the foundation of professional development workflow—you'll use them hundreds of times in this course and throughout your career. By the end, you'll have your first PR in your portfolio.

### Learning Outcomes
Focus on **doing**, not knowing:
- ✅ "Practice creating GitHub Issues with clear descriptions"
- ❌ "Understand how GitHub Issues work"

### Before You Begin
Be explicit about requirements:
```markdown
## Before You Begin

Make sure you have:
- [ ] Completed Reading 2: GitHub Workflow
- [ ] Access to your GitHub repository
- [ ] About 75 minutes of focused time

You'll need:
- A web browser (Chrome, Firefox, or Edge recommended)
- Your GitHub account credentials
```

### Step-by-Step Instructions

**Level of detail**: Someone unfamiliar should be able to follow without guessing.

**Good step**:
```markdown
### Step 1.2: Create a New Branch

1. In your repository, click the branch dropdown (it probably says "main")
2. In the text field, type: `1-add-introduction`
3. Click "Create branch: 1-add-introduction from main"

You should now see "1-add-introduction" in the branch dropdown instead of "main".

> **🔍 Why this branch name?** We prefix with "1-" to match our Issue number. 
> This makes it easy to connect branches to Issues later.
```

**Bad step**:
```markdown
### Step 1.2: Create a Branch

Create a new branch for your work.
```

### Screenshots/Visuals
Since we're writing markdown, describe what users should see:
```markdown
After clicking "Create branch," your screen should show:
- The branch dropdown now displays "1-add-introduction"
- The file list looks the same (you're on a copy of main)
- No error messages appear
```

### Checkpoints
Insert verification points throughout:
```markdown
## Checkpoint: After Part 1

At this point, you should have:
- [ ] One open Issue (#1) in your repository
- [ ] A branch named "1-add-introduction"
- [ ] Your README.md open in the editor

If anything is missing, review the steps above before continuing.
```

### Troubleshooting
Anticipate common problems:
```markdown
## Troubleshooting

**"I can't find the branch dropdown"**
Look for a button near the top-left of the file list that shows "main" 
with a small downward arrow. If you're on the repository's main page, 
it should be visible above the file listing.

**"My changes aren't showing up"**
Make sure you're on the correct branch. Check the branch dropdown—
it should show your feature branch name, not "main".

**"I accidentally committed to main"**
Don't panic! This is fixable. See the "Recovering from Mistakes" 
section in Reading 2, or ask for help in the class Discord.
```

### Submission
Be extremely specific:
```markdown
## Submission

Your lab is complete when:

1. **Your PR is open** with:
   - Title: "Fixes #1 - Add introduction"
   - Description filled out using the template
   - Link to Issue #1

2. **Your branch contains**:
   - Updated README.md with your introduction
   - At least 2 commits with meaningful messages

3. **In your Issue**:
   - Comment linking to your PR

**Do not merge your PR yet**—we'll do peer review in the next class.
```

## GitHub Integration Patterns

Every lab should reinforce the workflow:

### Before Work
```markdown
Before starting, create an Issue:
1. Go to Issues → New Issue
2. Title: "Lab 3: [Brief description]"
3. Assign yourself
4. Add label: "lab"
```

### Starting Work
```markdown
Create your working branch:
1. From the Issue page, click "Create a branch" (right sidebar)
2. Accept the suggested branch name
3. Open in Codespaces or clone locally
```

### During Work
Encourage regular commits:
```markdown
> **📝 Commit Point**: You've completed a logical chunk. 
> Commit now with message: "Add initial prompt template"
```

### After Work
Always end with PR:
```markdown
When finished, open a Pull Request:
1. Go to Pull Requests → New Pull Request
2. Set base: main, compare: your-branch
3. Fill in the description template
4. Link to your Issue using "Fixes #X"
```

## Scaffolding Patterns

### Starter Code
When providing code, use this pattern:
```markdown
Create a new file `assistant.py` with this starting code:

```python
# assistant.py
# Your SAGE Assistant - Lab 4

def create_prompt(topic):
    """
    Create a study prompt for the given topic.
    
    TODO: Implement this function in Step 2.2
    """
    pass  # Replace with your implementation


def main():
    topic = input("What would you like to study? ")
    prompt = create_prompt(topic)
    print(f"\nGenerated prompt:\n{prompt}")


if __name__ == "__main__":
    main()
```

This gives you the structure. Your job is to implement `create_prompt()`.
```

### Graduated Complexity
Start simple, add layers:
```markdown
## Part 1: Basic Implementation
[Minimum viable version]

## Part 2: Adding Polish
[Improve the basic version]

## Part 3: Stretch Goals
[Optional advanced features]
```

## Quality Checklist

Before completing a lab:

- [ ] Frontmatter complete (title, time, prerequisites, deliverables)
- [ ] Overview explains what and why
- [ ] Learning outcomes focus on skills practiced
- [ ] "Before You Begin" lists all requirements
- [ ] Steps are detailed enough to follow without guessing
- [ ] At least one checkpoint for self-verification
- [ ] Troubleshooting covers common issues
- [ ] Submission requirements are explicit
- [ ] Every instruction uses GitHub workflow
- [ ] Commit points marked throughout
- [ ] Stretch goals for early finishers
- [ ] Estimated time is realistic (tested if possible)

## Common Lab Types

### Exploration Lab
Goal: Discover through experimentation
```markdown
In this lab, you'll experiment with different prompt styles 
and document what works best. There's no single "right answer"—
the goal is building intuition through systematic exploration.
```

### Implementation Lab
Goal: Build something specific
```markdown
In this lab, you'll implement a study flashcard generator 
following a specific design. By the end, you'll have working 
code that you can extend in future labs.
```

### Integration Lab
Goal: Connect multiple concepts
```markdown
In this lab, you'll combine the prompting skills from Lab 3 
with the file handling from Lab 4 to create a complete 
study session tool.
```

### Review Lab
Goal: Apply skills to new context
```markdown
In this lab, you'll apply everything you've learned to a 
new problem domain: creating an assistant for a different 
subject area of your choosing.
```
